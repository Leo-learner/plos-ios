# Handoff: PLOS（Personal Learning OS）· Phase D 全套 UI

## Overview
PLOS 是一款单人使用的 iOS 学习工具：**月目标固定，日计划由本地确定性算法每天生成**。核心理念是「系统每天在运行」代替「靠意志力坚持」——允许失败（0% 日、休息日照常计入连续运行），不允许脱轨。本包包含全部 13 个屏、横切状态、可复用组件与设计 token，目标是用 **SwiftUI** 原生实现。

## About the Design Files
本包内的 `.dc.html` 文件是 **HTML 制作的设计参考稿**（高保真原型），**不是可直接上线的生产代码**。你的任务是在目标代码库（SwiftUI / iOS 17+）中**按既有工程规范重新实现**这些设计。在浏览器中打开 `PLOS Phase D.dc.html` 即可查看全部屏幕（画布可缩放平移）；`PLOS 原型.dc.html` 是可点击的日循环流程参考（注意：其文案为较早版本，**以 Phase D 文件为准**）。

## Fidelity
**High-fidelity（高保真）**。颜色、字号、间距、圆角、阴影、文案均为最终值，请像素级复刻；具体数值以 HTML 内联样式为准，本文档给出关键规格。

## 全局设计原则（实现时必须保持）
1. **全系统无红色**。失败/落后/0% 一律用 amber（琥珀）或中性色提示，绝不用红色崩盘感。
2. **reasoning 卡是信任元件**：15.5px 起、行高 1.78、关键数字加粗，永远显眼，不允许缩成小灰字。
3. 计划由**本地算法即时算出**——任何地方都没有「AI 思考中」loading 态。
4. 三种日类型一眼可辨：学习日=绿 g-500 系 / 节奏休息日=clay 陶土 / 灵活休息日=slate 青灰。
5. 连续运行天数（streak）在 0% 日与休息日**照样 +1**。
6. 数字一律用 Nunito（等宽数字 tabular-nums），中文用 Noto Sans SC（iOS 上可映射苹方 PingFang SC + SF Pro Rounded 数字）。

## Screens / Views（编号与画布一致）

### A · 起点
- **01 首次运行空态** — 纸底 paper，居中叶子图标（plosFloat 5.5s 浮动动画）+「还没有本月的系统」+ 理念卡 +主 CTA「建立本月计划」（g-500 药丸按钮，h54）。

### B · 建月设置（低频，信息密度高）
- **02 建月设置** — 分组表单：
  - 目标列表（可增删）：高数·deadline·6章·截止6/30·重要性1.2·达标80% ／ 英语·habit·每日阅读·达标70% ／ 线代·deadline·100题·截止6/28·达标80% ／ 项目·milestone·课程作业·截止6/25。每行含类型徽章（deadline/habit/milestone 分色）。
  - 休息策略：学 5 休 2 步进器 + 灵活休息日额度 2 天。
  - **考试与健康**模块：已导入考试徽章「高数 · 6/19」+ 虚线按钮「导入考试时间（日历/手动添加）」+「启用健康门槛」Toggle（开=g-500；说明文字：触发健康提醒·不改计划）。
  - 保底学习日预览卡（实时算出）：大数字 **20** 天 + 日历点阵 + 「单日基准将对齐这 20 天完成 100%」。

### C · 早晨 · 能量点选
- **03 能量三选（系统预填可改）** — 三张大卡：高能 150 min（amber 闪电）/ 普通 100 min（预选态：g 边框+勾）/ 低谷 45 min（peri 长春花）。副文案「按你近 7 天的汇报预填了普通」。CTA「生成今日计划」始终可用；下方提示「本地即时算出，无需等待」。顶部含考试倒计时轻量条（高数考试还剩 7 天）。

### C2 · 早晨 · 健康打卡（仅当 02 屏「健康门槛」开启时出现）
- **13 健康打卡** — 品牌绿全屏（g-500→g-700 170° 渐变，状态栏反白）。一句「今天户外运动了吗？」+ 滑到最右完成的滑块（白色圆滑块 48pt，轨道 rgba(255,255,255,.16)）+ 旁边「暂未完成」描边小按钮。页脚：打卡结果直接喂给健康提醒（连续 4 天未运动 → 次日早晨黄条）。**只影响提醒，不影响预算和计划。**

### D · 早晨 · 今日计划（学习日，三能量档）
共同结构：日期行 + 能量徽章 → 大数字预算（分钟·N 件事）→ 任务卡列表（序号方块 + 科目 + 分钟徽章 + label + 状态徽章 + 空心完成圈）→ **reasoning 卡** → 灵活休息按钮（剩 2/2）→ 底部一句「晚上回来花一分钟汇报」。
- **04 低谷日 · 45 min · 2 项** — 顶部黄色健康提醒条（可关 ×）「已连续 4 天未运动，今晚早点休息」。任务：线代 30（接昨天·落后节奏徽章）/ 英语 15（每日）。reasoning：低谷日预算压到 **45 分钟**，线代落后节奏 **27%**、**保底剩余学习日只剩 13 天**、压力最高，只保它和英语日常，其余明天再追。
- **05 普通日 · 35 min · 考前轻量** — 顶部 info 蓝灰条「明天高数考试：今天只复习，不上新内容」。任务：高数 20 min「错题复习 1–3 章」+ 徽章「考前·只复习」/ 英语 15。reasoning 说明让位逻辑 + 线代已过 80% 达标线降权。
- **12 高能日 · 150 min · 4 项** — 线代 55（落后节奏）/ 高数 50（推进 0.5 章 = 基准 0.23 章（剩 2.5 章 ÷ 11 天）高能日加倍）/ 项目 30（截止 6/25）/ 英语 15。reasoning 末句「单科上限 90 分钟，不透支」。

### E · 休息日（无惩罚感）
- **06 节奏休息日** — clay 暖底，「今天是计划内休息日」，无任务；「系统仍在运行 · 连续第 14 天」大字；页脚「明天回到学习日——接着上次的线代继续」。
- **07 灵活休息日（用掉 1 个后）** — slate 底，额度显示 1/2，streak 第 15 天照常。

### F · 计划视图（全天驻留主屏，<1 分钟扫完）
- **08 计划视图** — 今日条目（完成/进行中状态）+ reasoning 一行浓缩 + 极简月进度（各科横条：完成度 vs 达标线刻度；**线代已过 80% 达标线 → 「已达标 ✓」淡化让位但不消失**）+ 今日类型徽章 + 连续运行天数。

### G · 晚间汇报（低摩擦，一分钟）
- **09 汇报（正常）** — 逐项 0–100% 滑块：线代 80%（备忘「只刷了20题」）/ 英语 100%。个人备忘框标注「可选 · 仅记录，不影响明天计划」。保存按钮 g-500。
- **10 汇报（全 0%）** — 所有滑块 0%，无红色；文案中性：「保存后 → 连续运行第 22 天（0% 也计入）」。

### H · 数据面板（Phase P 预留位，本期只做占位风格）
- **11 仪表盘** — 各科完成率、学休比环形（学 20 : 休 10，67%）、streak 热力、「按保底节奏外推」卡（不做玄学预测）。

### I · 组件与 token 展板
画布最后一个 section 陈列全部可复用组件的隔离态，可作为组件验收基准。

## 可复用组件清单（建议的 SwiftUI 命名）
- `DayTypeBadge` — 学习日/节奏休息/灵活休息 药丸徽章（三配色）
- `EnergyCard` — 能量三选大卡（default / selected / 预填徽章）
- `TaskRow` — 任务卡：序号方块 27pt + 科目 + 分钟徽章（g-50 底 g-700 字）+ label + 状态徽章 + 24pt 完成圈
- `ReasoningCard` — g-50→#e5f0e8 渐变、g-100 边、叶子图标、标题「系统为什么这么排」、正文 15.5/1.78
- `HealthBanner` — amber 警示条（icon + 文案 + × 可关）；`InfoBanner` — slate 信息条（考前轻量）
- `FlexRestButton` — 描边药丸 + 额度徽章「灵活休息 2/2」
- `StreakLabel` — 绿点 + 「系统运行 · 连续第 N 天」
- `SubjectProgressBar` — 横条 + 达标线刻度 + 「已达标 ✓」淡化态
- `ReportSlider` — 0–100% 滑块行（科目 + 百分比大数字）
- `SlideToConfirm` — 健康打卡滑块（滑到最右触发）+ 「暂未完成」次按钮
- `PillButton` — 主 CTA（g-500 底/白字/h54/r999）与次级描边变体
- `GoalRow` / `BaselinePreviewCard` / `StepperRow` / `ToggleRow` — 建月设置表单元件

## Interactions & Behavior
- 能量卡点选 → 立即重算预算数字；「生成今日计划」→ **无 loading**，直接推入计划屏。
- 健康打卡滑块：拖到 ≥95% 吸附完成，haptic success；「暂未完成」直接记录并进入当天流程。
- 健康提醒条 ×：当日关闭，不改计划；仅在「健康门槛」开启且连续 ≥4 天未运动时出现。
- 灵活休息按钮 → 确认后当日转休息卡（07 样式），额度 −1。
- 晚间滑块保存：任何值（含全 0%）→ streak +1，无惩罚反馈。
- 空心完成圈点按 → 填充 g-500 打勾（计划视图内）。
- 动画参考：卡片浮现 translateY(-1px) hover 级别的轻反馈；图标浮动 5.5s ease-in-out；无夸张弹跳。

## State Management（建议）
- `MonthPlan`：goals[]（type: deadline/habit/milestone, total, unit, deadline, importance, successThreshold）、restPolicy(study:5, rest:2)、flexRestQuota(2)、exams[]（subject, date）、healthGateEnabled
- `DayState`：dayType(study/scheduledRest/flexRest)、energy(high/normal/low)、budgetMinutes、tasks[]（subject, minutes, label, tags）、reasoning(String)、healthCheck(done/skipped/none)
- `RunLog`：streakDays（休息与 0% 日照计）、dailyReports[]（per-goal 0–100%、memo）
- 派生值本地即时计算：保底学习日、落后节奏%、保底剩余学习日、考前模式（考试前一天 → 该科只复习）。

## Design Tokens
完整 SwiftUI 常量见 `DesignTokens.swift`。速查：

**颜色**（hex）
- 背景：canvas #E8ECE3 · paper #F6F8F2 · surface #FFFFFF · surface2 #EFF3EA
- 墨色：ink #26302A · ink2 #586159 · ink3 #8C958B · hairline #E5EADF
- 品牌绿 g50–g800：#EFF5F0 #DDEAE0 #BFD8C6 #98C0A5 #6FA381 **#4E8262(g500 主)** #3D6B4F #30553F #274633
- 语义：amber #B4842F/#F7EFD8（高能·警示）· peri #7A80C4/#ECEDF8（低谷）· clay #A2825C/#F1E9DB（节奏休息）· slate #5F8B98/#E7F0F1（灵活休息·info）· warn=amber 系 #A9802F/#F8EFD6
- 深色文字变体：amber 文字用 #8a6420，clay 用 #7a6034，slate 用 #436670

**字体**：中文 Noto Sans SC（iOS→PingFang SC）400/500/700/900；数字 Nunito（iOS→SF Pro Rounded 或捆绑 Nunito）600/700/800，一律 tabular-nums。
**字号阶**：11 / 11.5 / 12 / 12.5 / 13 / 13.5 / 14 / 14.5 / 15 / 15.5(reasoning 正文) / 16 / 17 / 20 / 23–24(页标题) / 26 / 28 / 34(大数字) px。
**圆角**：card 26 · lg 20 · md 14 · sm 10 · pill 999。
**阴影**：card `0 6 20 rgba(38,58,44,.06) + 0 1 2 .05` · pop `0 14 34 rgba(38,58,44,.13)`。
**间距节奏**：屏内边距 20–26 · 卡内边距 14–17 · 卡间 10–12 · 分组间 15–22。
**控件高度**：主按钮 54 · 次按钮/灵活休息 50 · 打卡滑块 58 · Toggle 29×48 · 最小可点 44。

## Assets
无位图资源。全部图标为内联 SVG（叶子 logo、闪电、日历、勾、箭头等），stroke 1.4–2.2，请在 SwiftUI 中用 SF Symbols 就近替换或按 SVG 路径重绘。字体来自 Google Fonts（Noto Sans SC、Nunito）。

## Files
- `PLOS Phase D.dc.html` — 主设计画布（13 屏 + 组件/token 展板，编号 01–13、区块 A–I）
- `PLOS 原型.dc.html` — 可点击日循环原型（流程参考；文案以 Phase D 为准）
- `support.js` — 打开 .dc.html 所需的运行时（保持同目录）
- `DesignTokens.swift` — 可直接拖入 Xcode 的 token 常量文件
